import styled from "@emotion/styled";

const Wrapper = styled.div`
  height: 50px;
  background-color: #f02020;
`;

export default function LayoutHeader() {
  return <Wrapper>헤더영역</Wrapper>;
}
