import WritePage from "../../../src/components/unit/example/write";

// 수정하기 나와야해 => isEdit: false
export default function EditPage() {
  return <WritePage />;
}
