import WritePage from "../../../src/components/unit/example/write";

// 등록하기 나와야해 => isEdit: true
export default function NewPage() {
  return <WritePage />;
}
