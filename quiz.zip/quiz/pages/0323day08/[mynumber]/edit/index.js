// 상품 수정 화면
import ProductWrite from "../../../src/product-write/ProductWrite.container"

export default function BoardEditPage() {
	return <ProductWrite isEdit={true}/>
}