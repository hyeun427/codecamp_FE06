// 상품 등록 화면
import ProductWrite from "../../src/product-write/ProductWrite.container"

export default function BoardNewPage() {
	return <ProductWrite isEdit={ false }/>
}