import BoardWrite from '../../day06/src/DynamicBoardInput.container'

export default function GraphqlMutationPage() {

	return <BoardWrite />
}