import styled from '@emotion/styled'

export const WriterInput = styled.input`
    background-color: skyblue;
`