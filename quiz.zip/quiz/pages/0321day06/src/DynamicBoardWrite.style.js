import styled from '@emotion/styled'

export const Contents = styled.div`
border-color: green;
`