import BoardWrite from '../src/DynamicBoardWrite.container'

export default function StaticRoutingPage() {

	return <BoardWrite />
}