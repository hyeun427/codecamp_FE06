import BoardWrite from "../../src/DynamicBoardWrite.container"




export default function StaticRoutedPage(){
    
    return <BoardWrite />
}