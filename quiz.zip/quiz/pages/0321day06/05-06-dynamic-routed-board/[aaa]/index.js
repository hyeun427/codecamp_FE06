import { BoardRead } from '../../../day06/src/DynamicBoardRead.container'

export default function StaticRoutedPage() {

	return <BoardRead/>
}