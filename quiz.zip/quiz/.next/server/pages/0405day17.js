"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/0405day17";
exports.ids = ["pages/0405day17"];
exports.modules = {

/***/ "./pages/0405day17/index.tsx":
/*!***********************************!*\
  !*** ./pages/0405day17/index.tsx ***!
  \***********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ OpenWithUseEffectPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! axios */ \"axios\");\n/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(axios__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);\n\n\n\nfunction OpenWithUseEffectPage() {\n    const { 0: dogUrl , 1: setDogUrl  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)(\"\");\n    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{\n        const aaa = async ()=>{\n            const result = await axios__WEBPACK_IMPORTED_MODULE_1___default().get(\"https://dog.ceo/dog-api/\");\n            setDogUrl(result.data.message);\n        };\n        aaa();\n    }, []);\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                children: \"오픈API 연습!!\"\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\0405day17\\\\index.tsx\",\n                lineNumber: 17,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"img\", {\n                src: dogUrl\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\0405day17\\\\index.tsx\",\n                lineNumber: 18,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\0405day17\\\\index.tsx\",\n        lineNumber: 16,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wNDA1ZGF5MTcvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7O0FBQXlCO0FBQ2tCO0FBRTVCLFFBQVEsQ0FBQ0cscUJBQXFCLEdBQUcsQ0FBQztJQUMvQyxLQUFLLE1BQUVDLE1BQU0sTUFBRUMsU0FBUyxNQUFJSCwrQ0FBUSxDQUFDLENBQUU7SUFFdkNELGdEQUFTLEtBQU8sQ0FBQztRQUNmLEtBQUssQ0FBQ0ssR0FBRyxhQUFlLENBQUM7WUFDdkIsS0FBSyxDQUFDQyxNQUFNLEdBQUcsS0FBSyxDQUFDUCxnREFBUyxDQUFDLENBQTBCO1lBQ3pESyxTQUFTLENBQUNFLE1BQU0sQ0FBQ0UsSUFBSSxDQUFDQyxPQUFPO1FBQy9CLENBQUM7UUFDREosR0FBRztJQUNMLENBQUMsRUFBRSxDQUFDLENBQUM7SUFFTCxNQUFNLDZFQUNISyxDQUFHOzt3RkFDREEsQ0FBRzswQkFBQyxDQUFVOzs7Ozs7d0ZBQ2RDLENBQUc7Z0JBQUNDLEdBQUcsRUFBRVQsTUFBTTs7Ozs7Ozs7Ozs7O0FBR3RCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzLzA0MDVkYXkxNy9pbmRleC50c3g/OWVmNCJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgYXhpb3MgZnJvbSBcImF4aW9zXCI7XHJcbmltcG9ydCB7IHVzZUVmZmVjdCwgdXNlU3RhdGUgfSBmcm9tIFwicmVhY3RcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIE9wZW5XaXRoVXNlRWZmZWN0UGFnZSgpIHtcclxuICBjb25zdCBbZG9nVXJsLCBzZXREb2dVcmxdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIHVzZUVmZmVjdCgoKSA9PiB7XHJcbiAgICBjb25zdCBhYWEgPSBhc3luYyAoKSA9PiB7XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGF4aW9zLmdldChcImh0dHBzOi8vZG9nLmNlby9kb2ctYXBpL1wiKTtcclxuICAgICAgc2V0RG9nVXJsKHJlc3VsdC5kYXRhLm1lc3NhZ2UpO1xyXG4gICAgfTtcclxuICAgIGFhYSgpO1xyXG4gIH0sIFtdKTtcclxuXHJcbiAgcmV0dXJuIChcclxuICAgIDxkaXY+XHJcbiAgICAgIDxkaXY+7Jik7ZSIQVBJIOyXsOyKtSEhPC9kaXY+XHJcbiAgICAgIDxpbWcgc3JjPXtkb2dVcmx9IC8+XHJcbiAgICA8L2Rpdj5cclxuICApO1xyXG59XHJcbiJdLCJuYW1lcyI6WyJheGlvcyIsInVzZUVmZmVjdCIsInVzZVN0YXRlIiwiT3BlbldpdGhVc2VFZmZlY3RQYWdlIiwiZG9nVXJsIiwic2V0RG9nVXJsIiwiYWFhIiwicmVzdWx0IiwiZ2V0IiwiZGF0YSIsIm1lc3NhZ2UiLCJkaXYiLCJpbWciLCJzcmMiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/0405day17/index.tsx\n");

/***/ }),

/***/ "axios":
/*!************************!*\
  !*** external "axios" ***!
  \************************/
/***/ ((module) => {

module.exports = require("axios");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/0405day17/index.tsx"));
module.exports = __webpack_exports__;

})();