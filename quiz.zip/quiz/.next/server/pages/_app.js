/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.js":
/*!***********************!*\
  !*** ./pages/_app.js ***!
  \***********************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! antd/dist/antd.css */ \"./node_modules/antd/dist/antd.css\");\n/* harmony import */ var antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(antd_dist_antd_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var _src_layout__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./src/layout */ \"./pages/src/layout/index.tsx\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var _src_styles_globalStyles__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! ./src/styles/globalStyles */ \"./pages/src/styles/globalStyles.ts\");\n/* harmony import */ var apollo_upload_client__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! apollo-upload-client */ \"apollo-upload-client\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([apollo_upload_client__WEBPACK_IMPORTED_MODULE_6__]);\napollo_upload_client__WEBPACK_IMPORTED_MODULE_6__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\n\n\nfunction MyApp({ Component , pageProps  }) {\n    const uploadLink = (0,apollo_upload_client__WEBPACK_IMPORTED_MODULE_6__.createUploadLink)({\n        uri: \"http://backend06.codebootcamp.co.kr/graphql\"\n    });\n    const client = new _apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloClient({\n        link: _apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloLink.from([\n            uploadLink\n        ]),\n        cache: new _apollo_client__WEBPACK_IMPORTED_MODULE_2__.InMemoryCache()\n    });\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_apollo_client__WEBPACK_IMPORTED_MODULE_2__.ApolloProvider, {\n        client: client,\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_emotion_react__WEBPACK_IMPORTED_MODULE_4__.Global, {\n                styles: _src_styles_globalStyles__WEBPACK_IMPORTED_MODULE_5__.globalStyles\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\_app.js\",\n                lineNumber: 25,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_src_layout__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {\n                children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n                    ...pageProps\n                }, void 0, false, {\n                    fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\_app.js\",\n                    lineNumber: 27,\n                    columnNumber: 9\n                }, this)\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\_app.js\",\n                lineNumber: 26,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\_app.js\",\n        lineNumber: 24,\n        columnNumber: 5\n    }, this));\n}\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (MyApp);\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBMkI7QUFNSjtBQUNVO0FBQ007QUFDaUI7QUFDRDtTQUU5Q1EsS0FBSyxDQUFDLENBQUMsQ0FBQ0MsU0FBUyxHQUFFQyxTQUFTLEVBQUMsQ0FBQyxFQUFFLENBQUM7SUFDeEMsS0FBSyxDQUFDQyxVQUFVLEdBQUdKLHNFQUFnQixDQUFDLENBQUM7UUFDbkNLLEdBQUcsRUFBRSxDQUE2QztJQUNwRCxDQUFDO0lBRUQsS0FBSyxDQUFDQyxNQUFNLEdBQUcsR0FBRyxDQUFDYix3REFBWSxDQUFDLENBQUM7UUFDL0JjLElBQUksRUFBRWIsMkRBQWUsQ0FBQyxDQUFDVTtZQUFBQSxVQUFVO1FBQUEsQ0FBQztRQUNsQ0ssS0FBSyxFQUFFLEdBQUcsQ0FBQ2IseURBQWE7SUFDMUIsQ0FBQztJQUVELE1BQU0sNkVBQ0hELDBEQUFjO1FBQUNXLE1BQU0sRUFBRUEsTUFBTTs7d0ZBQzNCUixrREFBTTtnQkFBQ1ksTUFBTSxFQUFFWCxrRUFBWTs7Ozs7O3dGQUMzQkYsbURBQU07c0dBQ0pLLFNBQVM7dUJBQUtDLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSWhDLENBQUM7QUFFRCxpRUFBZUYsS0FBSyxFQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy9fYXBwLmpzP2UwYWQiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IFwiYW50ZC9kaXN0L2FudGQuY3NzXCI7XHJcbmltcG9ydCB7XHJcbiAgQXBvbGxvQ2xpZW50LFxyXG4gIEFwb2xsb0xpbmssXHJcbiAgQXBvbGxvUHJvdmlkZXIsXHJcbiAgSW5NZW1vcnlDYWNoZSxcclxufSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcclxuaW1wb3J0IExheW91dCBmcm9tIFwiLi9zcmMvbGF5b3V0XCI7XHJcbmltcG9ydCB7IEdsb2JhbCB9IGZyb20gXCJAZW1vdGlvbi9yZWFjdFwiO1xyXG5pbXBvcnQgeyBnbG9iYWxTdHlsZXMgfSBmcm9tIFwiLi9zcmMvc3R5bGVzL2dsb2JhbFN0eWxlc1wiO1xyXG5pbXBvcnQgeyBjcmVhdGVVcGxvYWRMaW5rIH0gZnJvbSBcImFwb2xsby11cGxvYWQtY2xpZW50XCI7XHJcblxyXG5mdW5jdGlvbiBNeUFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcclxuICBjb25zdCB1cGxvYWRMaW5rID0gY3JlYXRlVXBsb2FkTGluayh7XHJcbiAgICB1cmk6IFwiaHR0cDovL2JhY2tlbmQwNi5jb2RlYm9vdGNhbXAuY28ua3IvZ3JhcGhxbFwiLFxyXG4gIH0pO1xyXG5cclxuICBjb25zdCBjbGllbnQgPSBuZXcgQXBvbGxvQ2xpZW50KHtcclxuICAgIGxpbms6IEFwb2xsb0xpbmsuZnJvbShbdXBsb2FkTGlua10pLFxyXG4gICAgY2FjaGU6IG5ldyBJbk1lbW9yeUNhY2hlKCksXHJcbiAgfSk7XHJcblxyXG4gIHJldHVybiAoXHJcbiAgICA8QXBvbGxvUHJvdmlkZXIgY2xpZW50PXtjbGllbnR9PlxyXG4gICAgICA8R2xvYmFsIHN0eWxlcz17Z2xvYmFsU3R5bGVzfSAvPlxyXG4gICAgICA8TGF5b3V0PlxyXG4gICAgICAgIDxDb21wb25lbnQgey4uLnBhZ2VQcm9wc30gLz5cclxuICAgICAgPC9MYXlvdXQ+XHJcbiAgICA8L0Fwb2xsb1Byb3ZpZGVyPlxyXG4gICk7XHJcbn1cclxuXHJcbmV4cG9ydCBkZWZhdWx0IE15QXBwO1xyXG4iXSwibmFtZXMiOlsiQXBvbGxvQ2xpZW50IiwiQXBvbGxvTGluayIsIkFwb2xsb1Byb3ZpZGVyIiwiSW5NZW1vcnlDYWNoZSIsIkxheW91dCIsIkdsb2JhbCIsImdsb2JhbFN0eWxlcyIsImNyZWF0ZVVwbG9hZExpbmsiLCJNeUFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyIsInVwbG9hZExpbmsiLCJ1cmkiLCJjbGllbnQiLCJsaW5rIiwiZnJvbSIsImNhY2hlIiwic3R5bGVzIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/_app.js\n");

/***/ }),

/***/ "./pages/src/layout/banner/index.tsx":
/*!*******************************************!*\
  !*** ./pages/src/layout/banner/index.tsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutBanner)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! slick-carousel/slick/slick.css */ \"./node_modules/slick-carousel/slick/slick.css\");\n/* harmony import */ var slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_css__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! slick-carousel/slick/slick-theme.css */ \"./node_modules/slick-carousel/slick/slick-theme.css\");\n/* harmony import */ var slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(slick_carousel_slick_slick_theme_css__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! react-slick */ \"react-slick\");\n/* harmony import */ var react_slick__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(react_slick__WEBPACK_IMPORTED_MODULE_5__);\n\n\n\n\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 200px;\n  width: 100%;\n  background-color: pink;\n`;\nconst settings = {\n    className: \"center\",\n    centerMode: true,\n    infinite: true,\n    centerPadding: \"60px\",\n    slidesToShow: 2,\n    speed: 500,\n    autoplay: true\n};\nconst Slide = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().img)`\n  width: 150px;\n`;\nfunction LayoutBanner() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n            children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)((react_slick__WEBPACK_IMPORTED_MODULE_5___default()), {\n                ...settings,\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Slide, {\n                            src: \"/carousel/beori2.jpg\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                            lineNumber: 33,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                        lineNumber: 32,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Slide, {\n                            src: \"/carousel/bori1.jpg\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                            lineNumber: 36,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                        lineNumber: 35,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Slide, {\n                            src: \"/carousel/beori1.jpg\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                            lineNumber: 39,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                        lineNumber: 38,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Slide, {\n                            src: \"/carousel/beoribori.jpg\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                            lineNumber: 42,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                        lineNumber: 41,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Slide, {\n                            src: \"/carousel/bori2.jpg\"\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                            lineNumber: 45,\n                            columnNumber: 13\n                        }, this)\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                        lineNumber: 44,\n                        columnNumber: 11\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n                        children: [\n                            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Slide, {\n                                src: \"/carousel/beori3.jpg\"\n                            }, void 0, false, {\n                                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                                lineNumber: 48,\n                                columnNumber: 13\n                            }, this),\n                            \" \"\n                        ]\n                    }, void 0, true, {\n                        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                        lineNumber: 47,\n                        columnNumber: 11\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n                lineNumber: 31,\n                columnNumber: 9\n            }, this)\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n            lineNumber: 30,\n            columnNumber: 7\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\banner\\\\index.tsx\",\n        lineNumber: 29,\n        columnNumber: 5\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9zcmMvbGF5b3V0L2Jhbm5lci9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBb0M7QUFDRztBQUNNO0FBQ0w7QUFDUjtBQUVoQyxLQUFLLENBQUNHLE9BQU8sR0FBR0gsNERBQVUsQ0FBQzs7OztBQUkzQjtBQUVBLEtBQUssQ0FBQ0ssUUFBUSxHQUFHLENBQUM7SUFDaEJDLFNBQVMsRUFBRSxDQUFRO0lBQ25CQyxVQUFVLEVBQUUsSUFBSTtJQUNoQkMsUUFBUSxFQUFFLElBQUk7SUFDZEMsYUFBYSxFQUFFLENBQU07SUFDckJDLFlBQVksRUFBRSxDQUFDO0lBQ2ZDLEtBQUssRUFBRSxHQUFHO0lBQ1ZDLFFBQVEsRUFBRSxJQUFJO0FBQ2hCLENBQUM7QUFFRCxLQUFLLENBQUNDLEtBQUssR0FBR2IsNERBQVUsQ0FBQzs7QUFFekI7QUFFZSxRQUFRLENBQUNlLFlBQVksR0FBRyxDQUFDO0lBQ3RDLE1BQU0sNkVBQ0haLE9BQU87OEZBQ0xDLENBQUc7a0dBQ0RGLG9EQUFNO21CQUFLRyxRQUFROztnR0FDakJELENBQUc7OEdBQ0RTLEtBQUs7NEJBQUNHLEdBQUcsRUFBQyxDQUFzQjs7Ozs7Ozs7Ozs7Z0dBRWxDWixDQUFHOzhHQUNEUyxLQUFLOzRCQUFDRyxHQUFHLEVBQUMsQ0FBcUI7Ozs7Ozs7Ozs7O2dHQUVqQ1osQ0FBRzs4R0FDRFMsS0FBSzs0QkFBQ0csR0FBRyxFQUFDLENBQXNCOzs7Ozs7Ozs7OztnR0FFbENaLENBQUc7OEdBQ0RTLEtBQUs7NEJBQUNHLEdBQUcsRUFBQyxDQUF5Qjs7Ozs7Ozs7Ozs7Z0dBRXJDWixDQUFHOzhHQUNEUyxLQUFLOzRCQUFDRyxHQUFHLEVBQUMsQ0FBcUI7Ozs7Ozs7Ozs7O2dHQUVqQ1osQ0FBRzs7d0dBQ0RTLEtBQUs7Z0NBQUNHLEdBQUcsRUFBQyxDQUFzQjs7Ozs7OzRCQUFJLENBQUc7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBTXBELENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzL3NyYy9sYXlvdXQvYmFubmVyL2luZGV4LnRzeD8xMjFiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xyXG5pbXBvcnQgXCJzbGljay1jYXJvdXNlbC9zbGljay9zbGljay5jc3NcIjtcclxuaW1wb3J0IFwic2xpY2stY2Fyb3VzZWwvc2xpY2svc2xpY2stdGhlbWUuY3NzXCI7XHJcbmltcG9ydCBSZWFjdCwgeyBDb21wb25lbnQgfSBmcm9tIFwicmVhY3RcIjtcclxuaW1wb3J0IFNsaWRlciBmcm9tIFwicmVhY3Qtc2xpY2tcIjtcclxuXHJcbmNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGhlaWdodDogMjAwcHg7XHJcbiAgd2lkdGg6IDEwMCU7XHJcbiAgYmFja2dyb3VuZC1jb2xvcjogcGluaztcclxuYDtcclxuXHJcbmNvbnN0IHNldHRpbmdzID0ge1xyXG4gIGNsYXNzTmFtZTogXCJjZW50ZXJcIixcclxuICBjZW50ZXJNb2RlOiB0cnVlLFxyXG4gIGluZmluaXRlOiB0cnVlLFxyXG4gIGNlbnRlclBhZGRpbmc6IFwiNjBweFwiLFxyXG4gIHNsaWRlc1RvU2hvdzogMixcclxuICBzcGVlZDogNTAwLFxyXG4gIGF1dG9wbGF5OiB0cnVlLFxyXG59O1xyXG5cclxuY29uc3QgU2xpZGUgPSBzdHlsZWQuaW1nYFxyXG4gIHdpZHRoOiAxNTBweDtcclxuYDtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIExheW91dEJhbm5lcigpIHtcclxuICByZXR1cm4gKFxyXG4gICAgPFdyYXBwZXI+XHJcbiAgICAgIDxkaXY+XHJcbiAgICAgICAgPFNsaWRlciB7Li4uc2V0dGluZ3N9PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPFNsaWRlIHNyYz1cIi9jYXJvdXNlbC9iZW9yaTIuanBnXCIgLz5cclxuICAgICAgICAgIDwvZGl2PlxyXG4gICAgICAgICAgPGRpdj5cclxuICAgICAgICAgICAgPFNsaWRlIHNyYz1cIi9jYXJvdXNlbC9ib3JpMS5qcGdcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8U2xpZGUgc3JjPVwiL2Nhcm91c2VsL2Jlb3JpMS5qcGdcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8U2xpZGUgc3JjPVwiL2Nhcm91c2VsL2Jlb3JpYm9yaS5qcGdcIiAvPlxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgICA8ZGl2PlxyXG4gICAgICAgICAgICA8U2xpZGUgc3JjPVwiL2Nhcm91c2VsL2JvcmkyLmpwZ1wiIC8+XHJcbiAgICAgICAgICA8L2Rpdj5cclxuICAgICAgICAgIDxkaXY+XHJcbiAgICAgICAgICAgIDxTbGlkZSBzcmM9XCIvY2Fyb3VzZWwvYmVvcmkzLmpwZ1wiIC8+e1wiIFwifVxyXG4gICAgICAgICAgPC9kaXY+XHJcbiAgICAgICAgPC9TbGlkZXI+XHJcbiAgICAgIDwvZGl2PlxyXG4gICAgPC9XcmFwcGVyPlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIlJlYWN0IiwiU2xpZGVyIiwiV3JhcHBlciIsImRpdiIsInNldHRpbmdzIiwiY2xhc3NOYW1lIiwiY2VudGVyTW9kZSIsImluZmluaXRlIiwiY2VudGVyUGFkZGluZyIsInNsaWRlc1RvU2hvdyIsInNwZWVkIiwiYXV0b3BsYXkiLCJTbGlkZSIsImltZyIsIkxheW91dEJhbm5lciIsInNyYyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/src/layout/banner/index.tsx\n");

/***/ }),

/***/ "./pages/src/layout/footer/index.tsx":
/*!*******************************************!*\
  !*** ./pages/src/layout/footer/index.tsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutFooter)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 50px;\n  background-color: green;\n`;\nfunction LayoutFooter() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"푸터영역\"\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\footer\\\\index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9zcmMvbGF5b3V0L2Zvb3Rlci9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQW9DO0FBRXBDLEtBQUssQ0FBQ0MsT0FBTyxHQUFHRCw0REFBVSxDQUFDOzs7QUFHM0I7QUFFZSxRQUFRLENBQUNHLFlBQVksR0FBRyxDQUFDO0lBQ3RDLE1BQU0sNkVBQUVGLE9BQU87a0JBQUMsQ0FBSTs7Ozs7O0FBQ3RCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzL3NyYy9sYXlvdXQvZm9vdGVyL2luZGV4LnRzeD80MTI2Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xyXG5cclxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6IGdyZWVuO1xyXG5gO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0Rm9vdGVyKCkge1xyXG4gIHJldHVybiA8V3JhcHBlcj7tkbjthLDsmIHsl608L1dyYXBwZXI+O1xyXG59XHJcbiJdLCJuYW1lcyI6WyJzdHlsZWQiLCJXcmFwcGVyIiwiZGl2IiwiTGF5b3V0Rm9vdGVyIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///./pages/src/layout/footer/index.tsx\n");

/***/ }),

/***/ "./pages/src/layout/header/index.tsx":
/*!*******************************************!*\
  !*** ./pages/src/layout/header/index.tsx ***!
  \*******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutHeader)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 50px;\n  background-color: #f02020;\n`;\nfunction LayoutHeader() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"헤더영역\"\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\header\\\\index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9zcmMvbGF5b3V0L2hlYWRlci9pbmRleC50c3guanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQW9DO0FBRXBDLEtBQUssQ0FBQ0MsT0FBTyxHQUFHRCw0REFBVSxDQUFDOzs7QUFHM0I7QUFFZSxRQUFRLENBQUNHLFlBQVksR0FBRyxDQUFDO0lBQ3RDLE1BQU0sNkVBQUVGLE9BQU87a0JBQUMsQ0FBSTs7Ozs7O0FBQ3RCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzL3NyYy9sYXlvdXQvaGVhZGVyL2luZGV4LnRzeD85MzFhIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBzdHlsZWQgZnJvbSBcIkBlbW90aW9uL3N0eWxlZFwiO1xyXG5cclxuY29uc3QgV3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgaGVpZ2h0OiA1MHB4O1xyXG4gIGJhY2tncm91bmQtY29sb3I6ICNmMDIwMjA7XHJcbmA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXRIZWFkZXIoKSB7XHJcbiAgcmV0dXJuIDxXcmFwcGVyPu2XpOuNlOyYgeyXrTwvV3JhcHBlcj47XHJcbn1cclxuIl0sIm5hbWVzIjpbInN0eWxlZCIsIldyYXBwZXIiLCJkaXYiLCJMYXlvdXRIZWFkZXIiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/src/layout/header/index.tsx\n");

/***/ }),

/***/ "./pages/src/layout/index.tsx":
/*!************************************!*\
  !*** ./pages/src/layout/index.tsx ***!
  \************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ Layout)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _banner__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./banner */ \"./pages/src/layout/banner/index.tsx\");\n/* harmony import */ var _footer__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./footer */ \"./pages/src/layout/footer/index.tsx\");\n/* harmony import */ var _header__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./header */ \"./pages/src/layout/header/index.tsx\");\n/* harmony import */ var _navigation__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./navigation */ \"./pages/src/layout/navigation/index.tsx\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_5__);\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(/*! next/router */ \"next/router\");\n/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_6__);\n\n\n\n\n\n\n\nfunction Layout(props) {\n    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_6__.useRouter)();\n    const BodyWrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_5___default().div)`\n    display: flex;\n  `;\n    const Body = (_emotion_styled__WEBPACK_IMPORTED_MODULE_5___default().div)`\n    height: auto;\n  `;\n    const Sidebar = (_emotion_styled__WEBPACK_IMPORTED_MODULE_5___default().div)`\n    width: 20%;\n    height: auto;\n    background-color: skyblue;\n  `;\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {\n        children: [\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_header__WEBPACK_IMPORTED_MODULE_3__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\index.tsx\",\n                lineNumber: 30,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_banner__WEBPACK_IMPORTED_MODULE_1__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\index.tsx\",\n                lineNumber: 31,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_navigation__WEBPACK_IMPORTED_MODULE_4__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\index.tsx\",\n                lineNumber: 32,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(BodyWrapper, {\n                children: [\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Sidebar, {\n                        children: \"사이드바 영역\"\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\index.tsx\",\n                        lineNumber: 34,\n                        columnNumber: 9\n                    }, this),\n                    /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Body, {\n                        children: props.children\n                    }, void 0, false, {\n                        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\index.tsx\",\n                        lineNumber: 35,\n                        columnNumber: 9\n                    }, this)\n                ]\n            }, void 0, true, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\index.tsx\",\n                lineNumber: 33,\n                columnNumber: 7\n            }, this),\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_footer__WEBPACK_IMPORTED_MODULE_2__[\"default\"], {}, void 0, false, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\index.tsx\",\n                lineNumber: 37,\n                columnNumber: 7\n            }, this)\n        ]\n    }, void 0, true));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9zcmMvbGF5b3V0L2luZGV4LnRzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBbUM7QUFDQTtBQUNBO0FBQ1E7QUFDUDtBQUVHO0FBTXhCLFFBQVEsQ0FBQ00sTUFBTSxDQUFDQyxLQUFtQixFQUFFLENBQUM7SUFDbkQsS0FBSyxDQUFDQyxNQUFNLEdBQUdILHNEQUFTO0lBQ3hCLEtBQUssQ0FBQ0ksV0FBVyxHQUFHTCw0REFBVSxDQUFDOztFQUUvQjtJQUVBLEtBQUssQ0FBQ08sSUFBSSxHQUFHUCw0REFBVSxDQUFDOztFQUV4QjtJQUNBLEtBQUssQ0FBQ1EsT0FBTyxHQUFHUiw0REFBVSxDQUFDOzs7O0VBSTNCO0lBRUEsTUFBTTs7d0ZBRURGLCtDQUFZOzs7Ozt3RkFDWkYsK0NBQVk7Ozs7O3dGQUNaRyxtREFBZ0I7Ozs7O3dGQUNoQk0sV0FBVzs7Z0dBQ1RHLE9BQU87a0NBQUMsQ0FBTzs7Ozs7O2dHQUNmRCxJQUFJO2tDQUFFSixLQUFLLENBQUNNLFFBQVE7Ozs7Ozs7Ozs7Ozt3RkFFdEJaLCtDQUFZOzs7Ozs7O0FBR25CLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzL3NyYy9sYXlvdXQvaW5kZXgudHN4P2M3M2MiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IExheW91dEJhbm5lciBmcm9tIFwiLi9iYW5uZXJcIjtcclxuaW1wb3J0IExheW91dEZvb3RlciBmcm9tIFwiLi9mb290ZXJcIjtcclxuaW1wb3J0IExheW91dEhlYWRlciBmcm9tIFwiLi9oZWFkZXJcIjtcclxuaW1wb3J0IExheW91dE5hdmlnYXRpb24gZnJvbSBcIi4vbmF2aWdhdGlvblwiO1xyXG5pbXBvcnQgc3R5bGVkIGZyb20gXCJAZW1vdGlvbi9zdHlsZWRcIjtcclxuaW1wb3J0IHsgUmVhY3ROb2RlIH0gZnJvbSBcInJlYWN0XCI7XHJcbmltcG9ydCB7IHVzZVJvdXRlciB9IGZyb20gXCJuZXh0L3JvdXRlclwiO1xyXG5cclxuaW50ZXJmYWNlIElMYXlvdXRQcm9wcyB7XHJcbiAgY2hpbGRyZW46IFJlYWN0Tm9kZTtcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgZnVuY3Rpb24gTGF5b3V0KHByb3BzOiBJTGF5b3V0UHJvcHMpIHtcclxuICBjb25zdCByb3V0ZXIgPSB1c2VSb3V0ZXIoKTtcclxuICBjb25zdCBCb2R5V3JhcHBlciA9IHN0eWxlZC5kaXZgXHJcbiAgICBkaXNwbGF5OiBmbGV4O1xyXG4gIGA7XHJcblxyXG4gIGNvbnN0IEJvZHkgPSBzdHlsZWQuZGl2YFxyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG4gIGA7XHJcbiAgY29uc3QgU2lkZWJhciA9IHN0eWxlZC5kaXZgXHJcbiAgICB3aWR0aDogMjAlO1xyXG4gICAgaGVpZ2h0OiBhdXRvO1xyXG4gICAgYmFja2dyb3VuZC1jb2xvcjogc2t5Ymx1ZTtcclxuICBgO1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPD5cclxuICAgICAgPExheW91dEhlYWRlciAvPlxyXG4gICAgICA8TGF5b3V0QmFubmVyIC8+XHJcbiAgICAgIDxMYXlvdXROYXZpZ2F0aW9uIC8+XHJcbiAgICAgIDxCb2R5V3JhcHBlcj5cclxuICAgICAgICA8U2lkZWJhcj7sgqzsnbTrk5zrsJQg7JiB7JetPC9TaWRlYmFyPlxyXG4gICAgICAgIDxCb2R5Pntwcm9wcy5jaGlsZHJlbn08L0JvZHk+XHJcbiAgICAgIDwvQm9keVdyYXBwZXI+XHJcbiAgICAgIDxMYXlvdXRGb290ZXIgLz5cclxuICAgIDwvPlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbIkxheW91dEJhbm5lciIsIkxheW91dEZvb3RlciIsIkxheW91dEhlYWRlciIsIkxheW91dE5hdmlnYXRpb24iLCJzdHlsZWQiLCJ1c2VSb3V0ZXIiLCJMYXlvdXQiLCJwcm9wcyIsInJvdXRlciIsIkJvZHlXcmFwcGVyIiwiZGl2IiwiQm9keSIsIlNpZGViYXIiLCJjaGlsZHJlbiJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/src/layout/index.tsx\n");

/***/ }),

/***/ "./pages/src/layout/navigation/index.tsx":
/*!***********************************************!*\
  !*** ./pages/src/layout/navigation/index.tsx ***!
  \***********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ LayoutNavigation)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst Wrapper = (_emotion_styled__WEBPACK_IMPORTED_MODULE_1___default().div)`\n  height: 50px;\n  background-color: orange;\n`;\nfunction LayoutNavigation() {\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Wrapper, {\n        children: \"네비게이션 영역\"\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\src\\\\layout\\\\navigation\\\\index.tsx\",\n        lineNumber: 9,\n        columnNumber: 10\n    }, this));\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9zcmMvbGF5b3V0L25hdmlnYXRpb24vaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7OztBQUFvQztBQUVwQyxLQUFLLENBQUNDLE9BQU8sR0FBR0QsNERBQVUsQ0FBQzs7O0FBRzNCO0FBRWUsUUFBUSxDQUFDRyxnQkFBZ0IsR0FBRyxDQUFDO0lBQzFDLE1BQU0sNkVBQUVGLE9BQU87a0JBQUMsQ0FBUTs7Ozs7O0FBQzFCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly9jbGFzcy8uL3BhZ2VzL3NyYy9sYXlvdXQvbmF2aWdhdGlvbi9pbmRleC50c3g/MGIyZiJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgc3R5bGVkIGZyb20gXCJAZW1vdGlvbi9zdHlsZWRcIjtcclxuXHJcbmNvbnN0IFdyYXBwZXIgPSBzdHlsZWQuZGl2YFxyXG4gIGhlaWdodDogNTBweDtcclxuICBiYWNrZ3JvdW5kLWNvbG9yOiBvcmFuZ2U7XHJcbmA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBMYXlvdXROYXZpZ2F0aW9uKCkge1xyXG4gIHJldHVybiA8V3JhcHBlcj7rhKTruYTqsozsnbTshZgg7JiB7JetPC9XcmFwcGVyPjtcclxufVxyXG4iXSwibmFtZXMiOlsic3R5bGVkIiwiV3JhcHBlciIsImRpdiIsIkxheW91dE5hdmlnYXRpb24iXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./pages/src/layout/navigation/index.tsx\n");

/***/ }),

/***/ "./pages/src/styles/globalStyles.ts":
/*!******************************************!*\
  !*** ./pages/src/styles/globalStyles.ts ***!
  \******************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"globalStyles\": () => (/* binding */ globalStyles)\n/* harmony export */ });\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! @emotion/react */ \"@emotion/react\");\n/* harmony import */ var _emotion_react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_emotion_react__WEBPACK_IMPORTED_MODULE_0__);\n\nconst globalStyles = _emotion_react__WEBPACK_IMPORTED_MODULE_0__.css`\n  * {\n    font-size: 30px;\n    box-sizing: border-box;\n    font-family: \"Courier New\", Courier, monospace;\n  }\n\n  @font-face {\n    font-family: \"myfont\";\n    src: url(\"/fonts/scifibit.ttf\");\n  }\n`;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9zcmMvc3R5bGVzL2dsb2JhbFN0eWxlcy50cy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7QUFBb0M7QUFFN0IsS0FBSyxDQUFDQyxZQUFZLEdBQUdELCtDQUFHLENBQUM7Ozs7Ozs7Ozs7O0FBV2hDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vY2xhc3MvLi9wYWdlcy9zcmMvc3R5bGVzL2dsb2JhbFN0eWxlcy50cz84MDA0Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNzcyB9IGZyb20gXCJAZW1vdGlvbi9yZWFjdFwiO1xyXG5cclxuZXhwb3J0IGNvbnN0IGdsb2JhbFN0eWxlcyA9IGNzc2BcclxuICAqIHtcclxuICAgIGZvbnQtc2l6ZTogMzBweDtcclxuICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7XHJcbiAgICBmb250LWZhbWlseTogXCJDb3VyaWVyIE5ld1wiLCBDb3VyaWVyLCBtb25vc3BhY2U7XHJcbiAgfVxyXG5cclxuICBAZm9udC1mYWNlIHtcclxuICAgIGZvbnQtZmFtaWx5OiBcIm15Zm9udFwiO1xyXG4gICAgc3JjOiB1cmwoXCIvZm9udHMvc2NpZmliaXQudHRmXCIpO1xyXG4gIH1cclxuYDtcclxuIl0sIm5hbWVzIjpbImNzcyIsImdsb2JhbFN0eWxlcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/src/styles/globalStyles.ts\n");

/***/ }),

/***/ "./node_modules/antd/dist/antd.css":
/*!*****************************************!*\
  !*** ./node_modules/antd/dist/antd.css ***!
  \*****************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick-theme.css":
/*!***********************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick-theme.css ***!
  \***********************************************************/
/***/ (() => {



/***/ }),

/***/ "./node_modules/slick-carousel/slick/slick.css":
/*!*****************************************************!*\
  !*** ./node_modules/slick-carousel/slick/slick.css ***!
  \*****************************************************/
/***/ (() => {



/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/react":
/*!*********************************!*\
  !*** external "@emotion/react" ***!
  \*********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/react");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

"use strict";
module.exports = require("@emotion/styled");

/***/ }),

/***/ "next/router":
/*!******************************!*\
  !*** external "next/router" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("next/router");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react-slick":
/*!******************************!*\
  !*** external "react-slick" ***!
  \******************************/
/***/ ((module) => {

"use strict";
module.exports = require("react-slick");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "apollo-upload-client":
/*!***************************************!*\
  !*** external "apollo-upload-client" ***!
  \***************************************/
/***/ ((module) => {

"use strict";
module.exports = import("apollo-upload-client");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.js"));
module.exports = __webpack_exports__;

})();