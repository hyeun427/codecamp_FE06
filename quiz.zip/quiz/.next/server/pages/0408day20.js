"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/0408day20";
exports.ids = ["pages/0408day20"];
exports.modules = {

/***/ "./pages/0408day20/index.tsx":
/*!***********************************!*\
  !*** ./pages/0408day20/index.tsx ***!
  \***********************************/
/***/ ((module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {\n__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ MapBoardPage)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! @apollo/client */ \"@apollo/client\");\n/* harmony import */ var _apollo_client__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_apollo_client__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! @emotion/styled */ \"@emotion/styled\");\n/* harmony import */ var _emotion_styled__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_emotion_styled__WEBPACK_IMPORTED_MODULE_2__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);\n/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! lodash */ \"lodash\");\n/* harmony import */ var lodash__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(lodash__WEBPACK_IMPORTED_MODULE_4__);\n/* harmony import */ var uuid__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(/*! uuid */ \"uuid\");\nvar __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([uuid__WEBPACK_IMPORTED_MODULE_5__]);\nuuid__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];\n\n\n\n\n\n\nconst FETCH_BOARDS = _apollo_client__WEBPACK_IMPORTED_MODULE_1__.gql`\n  query fetchBoards($search: String, $page: Int) {\n    fetchBoards(search: $search, page: $page) {\n      _id\n      writer\n      title\n      contents\n    }\n  }\n`;\nconst MyRow = (_emotion_styled__WEBPACK_IMPORTED_MODULE_2___default().div)`\n  display: flex;\n`;\nconst MyColumn = (_emotion_styled__WEBPACK_IMPORTED_MODULE_2___default().div)`\n  width: 25%;\n`;\nconst Word = (_emotion_styled__WEBPACK_IMPORTED_MODULE_2___default().span)`\n  color: ${(props)=>props.isMatched ? \"red\" : \"black\"\n};\n`;\nfunction MapBoardPage() {\n    const { 0: keyword , 1: setKeyword  } = (0,react__WEBPACK_IMPORTED_MODULE_3__.useState)(\"\");\n    const { data: data1 , refetch  } = (0,_apollo_client__WEBPACK_IMPORTED_MODULE_1__.useQuery)(FETCH_BOARDS);\n    const getDebounce = lodash__WEBPACK_IMPORTED_MODULE_4___default().debounce((data)=>{\n        refetch({\n            search: data,\n            page: 1\n        });\n        setKeyword(data);\n    }, 200);\n    const onChangeSearch = (event)=>{\n        getDebounce(event.target.value);\n    };\n    const onClickPage = (event)=>{\n        refetch({\n            page: Number(event.target.id)\n        });\n    };\n    return(/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"div\", {\n        children: [\n            \"검색어입력: \",\n            /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"input\", {\n                type: \"text\",\n                onChange: onChangeSearch\n            }, void 0, false, {\n                fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\0408day20\\\\index.tsx\",\n                lineNumber: 61,\n                columnNumber: 14\n            }, this),\n            data1 === null || data1 === void 0 ? void 0 : data1.fetchBoards.map((el1)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(MyRow, {\n                    children: [\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(MyColumn, {\n                            children: el1.writer\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\0408day20\\\\index.tsx\",\n                            lineNumber: 64,\n                            columnNumber: 11\n                        }, this),\n                        /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(MyColumn, {\n                            children: el1.title.replaceAll(keyword, `#$%${keyword}#$%`).split(\"#$%\").map((el)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Word, {\n                                    isMatched: keyword === el,\n                                    children: el\n                                }, (0,uuid__WEBPACK_IMPORTED_MODULE_5__.v4)(), false, {\n                                    fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\0408day20\\\\index.tsx\",\n                                    lineNumber: 70,\n                                    columnNumber: 17\n                                }, this)\n                            )\n                        }, void 0, false, {\n                            fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\0408day20\\\\index.tsx\",\n                            lineNumber: 65,\n                            columnNumber: 11\n                        }, this)\n                    ]\n                }, el1._id, true, {\n                    fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\0408day20\\\\index.tsx\",\n                    lineNumber: 63,\n                    columnNumber: 9\n                }, this)\n            ),\n            new Array(10).fill(1).map((_, index)=>/*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(\"span\", {\n                    onClick: onClickPage,\n                    id: String(index + 1),\n                    children: index + 1\n                }, index + 1, false, {\n                    fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\0408day20\\\\index.tsx\",\n                    lineNumber: 78,\n                    columnNumber: 9\n                }, this)\n            )\n        ]\n    }, void 0, true, {\n        fileName: \"C:\\\\Users\\\\hyeun\\\\Desktop\\\\codecamp_fe06\\\\quiz\\\\pages\\\\0408day20\\\\index.tsx\",\n        lineNumber: 60,\n        columnNumber: 5\n    }, this));\n};\n\n__webpack_async_result__();\n} catch(e) { __webpack_async_result__(e); } });//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy8wNDA4ZGF5MjAvaW5kZXgudHN4LmpzIiwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBOEM7QUFDVjtBQUNTO0FBS3ZCO0FBQ2E7QUFFbkMsS0FBSyxDQUFDTyxZQUFZLEdBQUdOLCtDQUFHLENBQUM7Ozs7Ozs7OztBQVN6QjtBQUVBLEtBQUssQ0FBQ08sS0FBSyxHQUFHTiw0REFBVSxDQUFDOztBQUV6QjtBQUVBLEtBQUssQ0FBQ1EsUUFBUSxHQUFHUiw0REFBVSxDQUFDOztBQUU1QjtBQU1BLEtBQUssQ0FBQ1MsSUFBSSxHQUFHVCw2REFBVyxDQUFDO1NBQ2hCLEdBQUdXLEtBQWEsR0FBTUEsS0FBSyxDQUFDQyxTQUFTLEdBQUcsQ0FBSyxPQUFHLENBQU87Q0FBRTtBQUNsRTtBQUVlLFFBQVEsQ0FBQ0MsWUFBWSxHQUFHLENBQUM7SUFDdEMsS0FBSyxNQUFFQyxPQUFPLE1BQUVDLFVBQVUsTUFBSWQsK0NBQVEsQ0FBQyxDQUFFO0lBRXpDLEtBQUssQ0FBQyxDQUFDLENBQUNlLElBQUksRUFBSkEsS0FBSSxHQUFFQyxPQUFPLEVBQUMsQ0FBQyxHQUFHbkIsd0RBQVEsQ0FHaENPLFlBQVk7SUFFZCxLQUFLLENBQUNhLFdBQVcsR0FBR2hCLHNEQUFVLEVBQUVjLElBQUksR0FBSyxDQUFDO1FBQ3hDQyxPQUFPLENBQUMsQ0FBQztZQUFDRyxNQUFNLEVBQUVKLElBQUk7WUFBRUssSUFBSSxFQUFFLENBQUM7UUFBQyxDQUFDO1FBQ2pDTixVQUFVLENBQUNDLElBQUk7SUFDakIsQ0FBQyxFQUFFLEdBQUc7SUFFTixLQUFLLENBQUNNLGNBQWMsSUFBSUMsS0FBb0MsR0FBSyxDQUFDO1FBQ2hFTCxXQUFXLENBQUNLLEtBQUssQ0FBQ0MsTUFBTSxDQUFDQyxLQUFLO0lBQ2hDLENBQUM7SUFFRCxLQUFLLENBQUNDLFdBQVcsSUFBSUgsS0FBSyxHQUFLLENBQUM7UUFDOUJOLE9BQU8sQ0FBQyxDQUFDO1lBQUNJLElBQUksRUFBRU0sTUFBTSxDQUFDSixLQUFLLENBQUNDLE1BQU0sQ0FBQ0ksRUFBRTtRQUFFLENBQUM7SUFDM0MsQ0FBQztJQUVELE1BQU0sNkVBQ0hyQixDQUFHOztZQUFDLENBQ0k7d0ZBQUNzQixDQUFLO2dCQUFDQyxJQUFJLEVBQUMsQ0FBTTtnQkFBQ0MsUUFBUSxFQUFFVCxjQUFjOzs7Ozs7WUFDakROLEtBQUksYUFBSkEsS0FBSSxLQUFKQSxJQUFJLENBQUpBLENBQWlCLEdBQWpCQSxJQUFJLENBQUpBLENBQWlCLEdBQWpCQSxLQUFJLENBQUVnQixXQUFXLENBQUNDLEdBQUcsRUFBRUMsR0FBRSwrRUFDdkI1QixLQUFLOztvR0FDSEUsUUFBUTtzQ0FBRTBCLEdBQUUsQ0FBQ0MsTUFBTTs7Ozs7O29HQUNuQjNCLFFBQVE7c0NBQ04wQixHQUFFLENBQUNFLEtBQUssQ0FDTkMsVUFBVSxDQUFDdkIsT0FBTyxHQUFHLEdBQUcsRUFBRUEsT0FBTyxDQUFDLEdBQUcsR0FDckN3QixLQUFLLENBQUMsQ0FBSyxNQUNYTCxHQUFHLEVBQUVDLEVBQUUsK0VBQ0x6QixJQUFJO29DQUFnQkcsU0FBUyxFQUFFRSxPQUFPLEtBQUtvQixFQUFFOzhDQUMzQ0EsRUFBRTttQ0FETTlCLHdDQUFNOzs7Ozs7Ozs7Ozs7bUJBUGI4QixHQUFFLENBQUNLLEdBQUc7Ozs7OztZQWNuQixHQUFHLENBQUNDLEtBQUssQ0FBQyxFQUFFLEVBQUVDLElBQUksQ0FBQyxDQUFDLEVBQUVSLEdBQUcsRUFBRS9CLENBQUMsRUFBRXdDLEtBQUssK0VBQ2pDaEMsQ0FBSTtvQkFBaUJpQyxPQUFPLEVBQUVqQixXQUFXO29CQUFFRSxFQUFFLEVBQUVnQixNQUFNLENBQUNGLEtBQUssR0FBRyxDQUFDOzhCQUM3REEsS0FBSyxHQUFHLENBQUM7bUJBRERBLEtBQUssR0FBRyxDQUFDOzs7Ozs7Ozs7Ozs7QUFNNUIsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovL2NsYXNzLy4vcGFnZXMvMDQwOGRheTIwL2luZGV4LnRzeD9kYmYxIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IHVzZVF1ZXJ5LCBncWwgfSBmcm9tIFwiQGFwb2xsby9jbGllbnRcIjtcclxuaW1wb3J0IHN0eWxlZCBmcm9tIFwiQGVtb3Rpb24vc3R5bGVkXCI7XHJcbmltcG9ydCB7IENoYW5nZUV2ZW50LCB1c2VTdGF0ZSB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQge1xyXG4gIElRdWVyeSxcclxuICBJUXVlcnlGZXRjaEJvYXJkc0FyZ3MsXHJcbn0gZnJvbSBcIi4uLy4uL3NyYy9jb21tb25zL3R5cGVzL2dlbmVyYXRlZC90eXBlc1wiO1xyXG5pbXBvcnQgXyBmcm9tIFwibG9kYXNoXCI7XHJcbmltcG9ydCB7IHY0IGFzIHV1aWR2NCB9IGZyb20gXCJ1dWlkXCI7XHJcblxyXG5jb25zdCBGRVRDSF9CT0FSRFMgPSBncWxgXHJcbiAgcXVlcnkgZmV0Y2hCb2FyZHMoJHNlYXJjaDogU3RyaW5nLCAkcGFnZTogSW50KSB7XHJcbiAgICBmZXRjaEJvYXJkcyhzZWFyY2g6ICRzZWFyY2gsIHBhZ2U6ICRwYWdlKSB7XHJcbiAgICAgIF9pZFxyXG4gICAgICB3cml0ZXJcclxuICAgICAgdGl0bGVcclxuICAgICAgY29udGVudHNcclxuICAgIH1cclxuICB9XHJcbmA7XHJcblxyXG5jb25zdCBNeVJvdyA9IHN0eWxlZC5kaXZgXHJcbiAgZGlzcGxheTogZmxleDtcclxuYDtcclxuXHJcbmNvbnN0IE15Q29sdW1uID0gc3R5bGVkLmRpdmBcclxuICB3aWR0aDogMjUlO1xyXG5gO1xyXG5cclxuaW50ZXJmYWNlIElQcm9wcyB7XHJcbiAgaXNNYXRjaGVkOiBib29sZWFuO1xyXG59XHJcblxyXG5jb25zdCBXb3JkID0gc3R5bGVkLnNwYW5gXHJcbiAgY29sb3I6ICR7KHByb3BzOiBJUHJvcHMpID0+IChwcm9wcy5pc01hdGNoZWQgPyBcInJlZFwiIDogXCJibGFja1wiKX07XHJcbmA7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBmdW5jdGlvbiBNYXBCb2FyZFBhZ2UoKSB7XHJcbiAgY29uc3QgW2tleXdvcmQsIHNldEtleXdvcmRdID0gdXNlU3RhdGUoXCJcIik7XHJcblxyXG4gIGNvbnN0IHsgZGF0YSwgcmVmZXRjaCB9ID0gdXNlUXVlcnk8XHJcbiAgICBQaWNrPElRdWVyeSwgXCJmZXRjaEJvYXJkc1wiPixcclxuICAgIElRdWVyeUZldGNoQm9hcmRzQXJnc1xyXG4gID4oRkVUQ0hfQk9BUkRTKTtcclxuXHJcbiAgY29uc3QgZ2V0RGVib3VuY2UgPSBfLmRlYm91bmNlKChkYXRhKSA9PiB7XHJcbiAgICByZWZldGNoKHsgc2VhcmNoOiBkYXRhLCBwYWdlOiAxIH0pO1xyXG4gICAgc2V0S2V5d29yZChkYXRhKTtcclxuICB9LCAyMDApO1xyXG5cclxuICBjb25zdCBvbkNoYW5nZVNlYXJjaCA9IChldmVudDogQ2hhbmdlRXZlbnQ8SFRNTElucHV0RWxlbWVudD4pID0+IHtcclxuICAgIGdldERlYm91bmNlKGV2ZW50LnRhcmdldC52YWx1ZSk7XHJcbiAgfTtcclxuXHJcbiAgY29uc3Qgb25DbGlja1BhZ2UgPSAoZXZlbnQpID0+IHtcclxuICAgIHJlZmV0Y2goeyBwYWdlOiBOdW1iZXIoZXZlbnQudGFyZ2V0LmlkKSB9KTtcclxuICB9O1xyXG5cclxuICByZXR1cm4gKFxyXG4gICAgPGRpdj5cclxuICAgICAg6rKA7IOJ7Ja07J6F66ClOiA8aW5wdXQgdHlwZT1cInRleHRcIiBvbkNoYW5nZT17b25DaGFuZ2VTZWFyY2h9IC8+XHJcbiAgICAgIHtkYXRhPy5mZXRjaEJvYXJkcy5tYXAoKGVsKSA9PiAoXHJcbiAgICAgICAgPE15Um93IGtleT17ZWwuX2lkfT5cclxuICAgICAgICAgIDxNeUNvbHVtbj57ZWwud3JpdGVyfTwvTXlDb2x1bW4+XHJcbiAgICAgICAgICA8TXlDb2x1bW4+XHJcbiAgICAgICAgICAgIHtlbC50aXRsZVxyXG4gICAgICAgICAgICAgIC5yZXBsYWNlQWxsKGtleXdvcmQsIGAjJCUke2tleXdvcmR9IyQlYClcclxuICAgICAgICAgICAgICAuc3BsaXQoXCIjJCVcIilcclxuICAgICAgICAgICAgICAubWFwKChlbCkgPT4gKFxyXG4gICAgICAgICAgICAgICAgPFdvcmQga2V5PXt1dWlkdjQoKX0gaXNNYXRjaGVkPXtrZXl3b3JkID09PSBlbH0+XHJcbiAgICAgICAgICAgICAgICAgIHtlbH1cclxuICAgICAgICAgICAgICAgIDwvV29yZD5cclxuICAgICAgICAgICAgICApKX1cclxuICAgICAgICAgIDwvTXlDb2x1bW4+XHJcbiAgICAgICAgPC9NeVJvdz5cclxuICAgICAgKSl9XHJcbiAgICAgIHtuZXcgQXJyYXkoMTApLmZpbGwoMSkubWFwKChfLCBpbmRleCkgPT4gKFxyXG4gICAgICAgIDxzcGFuIGtleT17aW5kZXggKyAxfSBvbkNsaWNrPXtvbkNsaWNrUGFnZX0gaWQ9e1N0cmluZyhpbmRleCArIDEpfT5cclxuICAgICAgICAgIHtpbmRleCArIDF9XHJcbiAgICAgICAgPC9zcGFuPlxyXG4gICAgICApKX1cclxuICAgIDwvZGl2PlxyXG4gICk7XHJcbn1cclxuIl0sIm5hbWVzIjpbInVzZVF1ZXJ5IiwiZ3FsIiwic3R5bGVkIiwidXNlU3RhdGUiLCJfIiwidjQiLCJ1dWlkdjQiLCJGRVRDSF9CT0FSRFMiLCJNeVJvdyIsImRpdiIsIk15Q29sdW1uIiwiV29yZCIsInNwYW4iLCJwcm9wcyIsImlzTWF0Y2hlZCIsIk1hcEJvYXJkUGFnZSIsImtleXdvcmQiLCJzZXRLZXl3b3JkIiwiZGF0YSIsInJlZmV0Y2giLCJnZXREZWJvdW5jZSIsImRlYm91bmNlIiwic2VhcmNoIiwicGFnZSIsIm9uQ2hhbmdlU2VhcmNoIiwiZXZlbnQiLCJ0YXJnZXQiLCJ2YWx1ZSIsIm9uQ2xpY2tQYWdlIiwiTnVtYmVyIiwiaWQiLCJpbnB1dCIsInR5cGUiLCJvbkNoYW5nZSIsImZldGNoQm9hcmRzIiwibWFwIiwiZWwiLCJ3cml0ZXIiLCJ0aXRsZSIsInJlcGxhY2VBbGwiLCJzcGxpdCIsIl9pZCIsIkFycmF5IiwiZmlsbCIsImluZGV4Iiwib25DbGljayIsIlN0cmluZyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/0408day20/index.tsx\n");

/***/ }),

/***/ "@apollo/client":
/*!*********************************!*\
  !*** external "@apollo/client" ***!
  \*********************************/
/***/ ((module) => {

module.exports = require("@apollo/client");

/***/ }),

/***/ "@emotion/styled":
/*!**********************************!*\
  !*** external "@emotion/styled" ***!
  \**********************************/
/***/ ((module) => {

module.exports = require("@emotion/styled");

/***/ }),

/***/ "lodash":
/*!*************************!*\
  !*** external "lodash" ***!
  \*************************/
/***/ ((module) => {

module.exports = require("lodash");

/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

module.exports = require("react/jsx-dev-runtime");

/***/ }),

/***/ "uuid":
/*!***********************!*\
  !*** external "uuid" ***!
  \***********************/
/***/ ((module) => {

module.exports = import("uuid");;

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/0408day20/index.tsx"));
module.exports = __webpack_exports__;

})();